# TextAnimation

A prototype of text animation shader

![gif](http://33.media.tumblr.com/c162cc9841f09f58126edbc5129d1a3c/tumblr_nxhuscM7qJ1qio469o1_400.gif)
![gif](http://33.media.tumblr.com/11727db1165e885c0b288195c4059b4e/tumblr_nxhl02wvnQ1qio469o1_400.gif)
![gif](http://33.media.tumblr.com/f15e5c652234627fd1028552e6a25e09/tumblr_nxehycihNc1qio469o1_400.gif)
